const members = [
    {   
        id: 1,
        roll_number: 1,
        name: 'Rahul Wahi',
        status: 'active',
    },

    {   
        id: 2,
        roll_number: 2,
        name: 'Naveen Bansal',
        status: 'active',
    },
    {   
        id: 3,
        roll_number: 3,
        name: 'John Lage',
        status: 'active',
    },
    {   
        id: 4,
        roll_number: 4,
        name: 'Rohan Joshi',
        status: 'inactive',
    },
    {   
        id: 5,
        roll_number: 5,
        name: 'Aditya Singh',
        status: 'active',
    }
];



module.exports= members;